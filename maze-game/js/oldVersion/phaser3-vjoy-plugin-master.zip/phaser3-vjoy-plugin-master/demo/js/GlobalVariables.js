var myGame = {
    // Define our game states
    scenes: [],

    // Define common framerate to be referenced in animations
    frameRate: 10
};
